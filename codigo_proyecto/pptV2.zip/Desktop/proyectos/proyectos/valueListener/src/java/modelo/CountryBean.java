
import java.io.Serializable;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.faces.event.ValueChangeEvent;

@SessionScoped
@Named("country")
public class CountryBean implements Serializable {

    private String localeCode = "es";
    private int eventCounter = 0;

    public CountryBean() {
    }

    public void listener(ValueChangeEvent e) {
//en este caso el oyente cuenta el número de eventos por cambio de valor eventCounter = eventCounter + 1;

        eventCounter = eventCounter + 1; 
        System.out.println("---> EVENT LOCALE CODE: " + e.getNewValue().toString());
        System.out.println("---> TRIGGER: " + eventCounter);
}
public String getLocaleCode() {
     return localeCode ;
    }
   

    public void setLocaleCode(String localeCode) {
        this.localeCode  = localeCode;
    }
     
    

    public int getEventCounter() {
        return eventCounter;
    }

    public void setEventCounter(int eventCounter) {
        this.eventCounter = eventCounter; 
    }
}

 