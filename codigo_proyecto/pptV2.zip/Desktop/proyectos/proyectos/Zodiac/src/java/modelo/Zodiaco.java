package modelo;

import java.awt.Point;
import java.awt.Rectangle;
import java.util.Map;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;

@Named(value = "zodiaco")
@RequestScoped
public class Zodiaco {

    private Point click;
// Rectangle --> upper-left pont (x, y), width, height
    final private Rectangle aries = new Rectangle(15, 205, 70, 70);
    final private Rectangle leo = new Rectangle(275, 265, 70, 70);
    final private Rectangle capricornio = new Rectangle(125, 0, 70, 70);
    final private Rectangle sagitario = new Rectangle(200, 0, 70, 70);
    final private Rectangle escorpio = new Rectangle(275, 55, 70, 70);
    final private Rectangle libra = new Rectangle(325, 125, 70, 70);
    final private Rectangle virgo = new Rectangle(320, 205, 70, 70);
    final private Rectangle cancer = new Rectangle(215, 315, 70, 70);
    final private Rectangle geminis = new Rectangle(135, 320, 70, 70);
    final private Rectangle tauro = new Rectangle(65, 275, 70, 70);
    final private Rectangle piscis = new Rectangle(20, 120, 70, 70);
    final private Rectangle acuario = new Rectangle(65, 50, 70, 70);
        
    public Zodiaco() {
    }

    public void oyente(ActionEvent e) {
        FacesContext context = FacesContext.getCurrentInstance();
        String clientId = e.getComponent().getClientId(context);
        Map requestParams = context.getExternalContext().getRequestParameterMap();
        int x = new Integer((String) requestParams.get(clientId + ".x"));
        int y = new Integer((String) requestParams.get(clientId + ".y"));
        click = new Point(x, y);
        System.out.println("----> ACTION_EVENT: " + e.toString());
        System.out.println( "----> COORDS" + click.toString());
   
}
public String accion() {
        String resultado;
        if (aries.contains(click)) {
            resultado = "aries";
        } else if (leo.contains(click)) {
            resultado = "leo";
        } else if (capricornio.contains(click)) {
            resultado = "capricornio";
        } else if (sagitario.contains(click)) {
            resultado = "sagitario";
        } else if (escorpio.contains(click)) {
            resultado = "escorpio";
        } else if (libra.contains(click)) {
            resultado = "libra";
        } else if (virgo.contains(click)) {
            resultado = "virgo";
        } else if (cancer.contains(click)) {
            resultado = "cancer";
        } else if (geminis.contains(click)) {
            resultado = "geminis";
        } else if (tauro.contains(click)) {
            resultado = "tauro";
        } else if (piscis.contains(click)) {
            resultado = "piscis";
        } else if (acuario.contains(click)) {
            resultado = "acuario";
        }  else {
            resultado = "error";
        }
        
        return resultado; 
    
                }
}
