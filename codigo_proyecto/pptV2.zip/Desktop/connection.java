package modelo;

import java.sql.*;

public class connection {

 Connection con = null;

 public static Connection connectDB()

 {

     try {


         Class.forName("com.mysql.jdbc.Driver");

         Connection con = DriverManager.getConnection(
             "jdbc:mysql://localhost:3380/mydb",
             "Javadb12", "Javadb12");
         return con;
     }

     catch (SQLException | ClassNotFoundException e) {

         System.out.println(e);

         return null;
     }
 }
}