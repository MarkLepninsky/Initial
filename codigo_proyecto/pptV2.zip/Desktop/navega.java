/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import javax.inject.Named;
import javax.enterprise.context.RequestScoped;

/**
 *
 * @author nsanher1
 */
@Named(value = "navega")
@RequestScoped
public class navega {

    /**
     * Creates a new instance of navega
     */
    public navega() {
    }

    public String gotoCliente() {
        return "cliente.xhtml?faces-redirect=true";
    }

    public String gotoCrear_Cliente() {
        return "crear_usuario.xhtml?faces-redirect=true";
    }

    public String gotoCrear_Juego() {
        return "crear_juego.xhtml?faces-redirect=true";
    }

    public String gotoList_Juego() {
        return "list_juego.xhtml?faces-redirect=true";
    }

    public String gotoLogin() {
        return "login.xhtml?faces-redirect=true";
    }

    public String gotoJugar_Partida() {
        return "jugar_partida.xhtml?faces-redirect=true";
    }
    
     public String gotoJugar_Torneo() {
        return "jugar_torneo.xhtml?faces-redirect=true";
    }
}
