package modelo;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import java.util.ArrayList;
import java.util.List;

@ManagedBean(name = "carritoBean")
@SessionScoped
public class CarritoBean {
    public int desbloqueo = 0;
    public boolean bloqueo = true;
    private List<Producto> productosEnCarrito;

    // Constructor
    public CarritoBean() {
        productosEnCarrito = new ArrayList<>();
        
        productosEnCarrito.add(new Producto("lightstick_bts", 95.00));
        productosEnCarrito.add(new Producto("album_bts", 45.00));
        productosEnCarrito.add(new Producto("lightstick_illis", 95.00));
        productosEnCarrito.add(new Producto("album_illis", 45.00));
        productosEnCarrito.add(new Producto("lightstick_bp", 95.00));
        productosEnCarrito.add(new Producto("album_bp", 45.00));
        productosEnCarrito.add(new Producto("lightstick_itzy", 95.00));
        productosEnCarrito.add(new Producto("album_itzy", 45.00));
        productosEnCarrito.add(new Producto("lightstick_skz", 95.00));
        productosEnCarrito.add(new Producto("album_skz", 45.00));
        productosEnCarrito.add(new Producto("lightstick_txt", 95.00));
        productosEnCarrito.add(new Producto("album_txt", 45.00));
    }

    public List<Producto> getProductCart() {
        List<Producto> productosConCantidadMayorA1 = new ArrayList<>();
        for (Producto producto : productosEnCarrito) {
            if (producto.getCantidad() > 0) {
                productosConCantidadMayorA1.add(producto);
            }
        }
        return productosConCantidadMayorA1;
    }

    public double getTotal() {
        double total = 0.0;
        for (Producto producto : productosEnCarrito) {
            total += producto.getTotal();
        }
        return total;
    }
    
    public void desbloquear(){
    if(desbloqueo > 0){
        bloqueo = false;
    } else{
        bloqueo = true;
    }
    }
    
    public void addProductToCart(String nombreProducto) {
        for (Producto producto : productosEnCarrito) {
            if (producto.getNombre().equals(nombreProducto)) {
                producto.incrementarCantidad();
                desbloqueo++;
                desbloquear();
                break;
            }
        }
    }
    
public void RemoveProductCart(String nombreProducto) {
    for (Producto producto : productosEnCarrito) {
        if (producto.getNombre().equals(nombreProducto)) {
            if (producto.getCantidad() > 0) {
                producto.decrementarCantidad();
                desbloqueo--;
                desbloquear();
            } else  {
            }   break;
        }
    }
}

    public void EmptyCart() {
        for (Producto producto : productosEnCarrito) {
            producto.setCantidad(0);
            desbloqueo = 0;
        }
    }
    public boolean tieneProductos() {
    for (Producto producto : productosEnCarrito) {
        if (producto.getCantidad() > 0) {
            return true;
        }
    }
    return false;
}
    
    public void updateQuantity(String productName, int change) {
    if (change > 0) {
        addProductToCart(productName); 
    } else if (change < 0) {
        RemoveProductCart(productName);
    }
    }
    public int getProductQuantity(String productName) {
    for (Producto producto : productosEnCarrito) {
        if (producto.getNombre().equals(productName)) {
            return producto.getCantidad();
        }
    }
    return 0;
}

}
