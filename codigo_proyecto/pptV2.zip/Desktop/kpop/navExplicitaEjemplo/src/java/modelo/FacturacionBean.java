package modelo;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean(name = "facturacionBean")
@SessionScoped
public class FacturacionBean {

    private String nombre;
    private String apellido;
    private String direccion;
    private String email;
    private String telefono;
    private String tarjetaCredito;

    private boolean camposCompletos = false;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
        verificarCamposCompletos();
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
        verificarCamposCompletos();
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
        verificarCamposCompletos();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
        verificarCamposCompletos();
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
        verificarCamposCompletos();
    }

    public String getTarjetaCredito() {
        return tarjetaCredito;
    }

    public void setTarjetaCredito(String tarjetaCredito) {
        this.tarjetaCredito = tarjetaCredito;
        verificarCamposCompletos();
    }

    public void verificarCamposCompletos() {
        if (nombre != null &&
            apellido != null &&
            direccion != null &&
            email != null && 
            telefono != null &&
            tarjetaCredito != null){
            camposCompletos = true;
        } else {
            camposCompletos = false;
        }
    }

    public boolean isCamposCompletos() {
        return camposCompletos;
    }

    public void setCamposCompletos(boolean camposCompletos) {
        this.camposCompletos = camposCompletos;
    }
}
