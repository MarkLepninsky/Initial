/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javabeans;

import javax.inject.Named;
import javax.enterprise.context.RequestScoped;

/**
 *
 * @author EMONMON
 */
@Named(value = "navega")
@RequestScoped
public class Navegador {

    /**
     * Creates a new instance of Navegador
     */
    public Navegador() {
    }
    
    public String indice(){
        return "paginaSiguiente";
    }
    
    public String carrito(){
        return "paginaSiguiente";
    }
    
    public String clientes(){
        return "paginaSiguiente";
    }
    
    public String productos(){
        return "paginaSiguiente";
    }
    
    public String crea_cliente(){
        return "paginaSiguiente";
    }
    
    public String tienda(){
        return "paginaSiguiente";
    }
    public String bg(){
        return "paginaSiguiente";
    }
    
    public String gg(){
        return "paginaSiguiente";
    }
    
    public String blackpink(){
        return "paginaSiguiente";
    }
    public String illit(){
        return "paginaSiguiente";
    }
    
    public String itzy(){
        return "paginaSiguiente";
    }
    
    public String skz(){
        return "paginaSiguiente";
    }
    public String bts(){
        return "paginaSiguiente";
    }
    
    public String txt(){
        return "paginaSiguiente";
    }
    public String facturacion(){
        return "paginaSiguiente";
    }
    
   
    
}
