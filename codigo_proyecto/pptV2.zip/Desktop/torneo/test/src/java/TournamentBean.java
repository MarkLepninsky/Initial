import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;

@Named(value = "tournamentBean")
@SessionScoped
public class TournamentBean implements Serializable {

    // Inner class representing a player in the tournament
    public class TournamentPlayer {
        private String name;
        private String move;
        private int score;

        public TournamentPlayer(String name, String move) {
            this.name = name;
            this.move = move;
        }

        public String getName() {
            return name;
        }

        public String getMove() {
            return move;
        }

        public void incrementScore() {
            this.score++;
        }
    }

    private ArrayList<TournamentPlayer> players = new ArrayList<>();

    public ArrayList<TournamentPlayer> playTournament() {
        ArrayList<TournamentPlayer> playersTemp = new ArrayList<>();
        
        // Loop until we have a single winner
        while (players.size() > 1) {
            // Handle odd number of players: Move first to temp list
            if (players.size() % 2 != 0) {
                TournamentPlayer playerTemp1 = players.remove(0);
                playersTemp.add(playerTemp1);
            }
            
            int index = players.size() / 2;
            for (int i = 0; i < players.size() / 2; i++) {
                playersTemp.add(jugarPartida(crearPartida(players.get(i), players.get(index + i))));
            }

            // Move winners from temp list back to players list
            players.clear();
            players.addAll(playersTemp);
            playersTemp.clear();
        }
        return players;
    }

    private TournamentPlayer crearPartida(TournamentPlayer player1, TournamentPlayer player2) {
        // Mockup logic for creating a match, modify as needed
        return (Math.random() < 0.5) ? player1 : player2;
    }

    private TournamentPlayer jugarPartida(TournamentPlayer winner) {
        winner.incrementScore();
        return winner;
    }

    public TournamentBean() {
        // Add initial players (example only)
        players.add(new TournamentPlayer("Alice", "Rock"));
        players.add(new TournamentPlayer("Bob", "Paper"));
        players.add(new TournamentPlayer("Charlie", "Scissors"));
        players.add(new TournamentPlayer("David", "Lizard"));
    }

    public ArrayList<TournamentPlayer> getPlayers() {
        return players;
    }
}
