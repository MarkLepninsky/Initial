/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.sql.*;

/**
 *
 * @author jdong
 */
@Named(value = "partidaBean")
@SessionScoped
public class PartidaBean implements Serializable {

   
    
    public class Move{
        private int id;
        private String name;
    }
    
    public class Partida{
    private PlayerBean.Player player1,player2;
    private Move moveJugador1,moveJugador2;
     
        public Partida(PlayerBean.Player player1,PlayerBean.Player player2){
            this.player1= player1;
            this.player2= player2;
        }
        
    }
    
    public PartidaBean() {
    }
    public Partida crearPartida(PlayerBean.Player player1, PlayerBean.Player player2){
        Partida partida = new Partida(player1,player2);
        try{
               Connection con = null;
               PreparedStatement ps = null;
                ResultSet rs = null;
                int id = 0;
                con = connector.connectDB();
                String sql = "Select * from Partida";
                ps = con.prepareStatement(sql);
                rs = ps.executeQuery(sql);
                while(rs.next()){
                id = rs.getInt("id");
                }
                id++;
                
        } catch (Exception e){
            System.out.println(e);
        }

        
        
        
        return partida;
    }
    public PlayerBean.Player jugarPartida(Partida partida){
        if(partida.moveJugador1.name == "piedra" && partida.moveJugador2.name == "papel"){
            return partida.player2;
        } else if(partida.moveJugador1.name== "piedra" && partida.moveJugador2.name== "tijera"){
            return partida.player1; 
        } else if(partida.moveJugador1.name== "papel" && partida.moveJugador2.name== "tijera"){
            return partida.player2;
        } else if(partida.moveJugador1.name== "papel" && partida.moveJugador2.name== "pierdra"){
            return partida.player1;
        } else if(partida.moveJugador1.name== "tijera" && partida.moveJugador2.name== "papel"){
            return partida.player1;
        } else if(partida.moveJugador1.name== "rijera" && partida.moveJugador2.name== "pierdra"){
            return partida.player2;
        } 
        return null;
    }
    
   
}
