import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.sql.*;

@Named(value = "playerbean")
@SessionScoped
public class PlayerBean implements Serializable {

    public PlayerBean() {
        players.add(new Player("Alice", "alice@example.com", "password123"));
        players.add(new Player("Bob", "bob@example.com", "securepass456"));
        players.add(new Player("Charlie", "charlie@example.com", "mypassword789"));
        numPlayers = players.size();
    }

    private String tempName;
    private String tempEmail;
    private String tempPass;
    private int numPlayers = 0;
    
    private ArrayList<Player> players = new ArrayList<>();

    public class Player {
        private String name;
        private String email;
        private String pass;
        private int score;
        
        public Player(String name, String email, String pass) {
            this.name = name;
            this.email = email;
            this.pass = pass;
        }

        public String getName() {
            Connection con = null;
            PreparedStatement ps = null;
            ResultSet rs = null;
            String nombre = "";
            try{
            con = connector.connectDB();
            String sql = "Select * from Usuario";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery(sql);
            while(rs.next()){
            nombre += rs.getString("Nombre");
            }
            }catch(Exception e){
            System.out.println(e);
            }
            return nombre;
        }

        public String getEmail() {
            return email;
        }

        public String getPass() {
            Connection con = null;
            PreparedStatement ps = null;
            ResultSet rs = null;
            String password = "";
            try{
            con = connector.connectDB();
            String sql = "Select * from Usuario";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery(sql);
            while(rs.next()){
            password += rs.getString("Password");
            }
            }catch(Exception e){
            System.out.println(e);
            }
            return password;
        }
    }

    

    public ArrayList<Player> getPlayers() {
        return players;
    }

    public String getTempName() {
        return tempName;
    }

    public void setTempName(String tempName) {
        this.tempName = tempName;
    }

    public String getTempPass() {
        return tempPass;
    }

    public void setTempPass(String tempPass) {
        this.tempPass = tempPass;
    }

    public String getTempEmail() {
        return tempEmail;
    }

    public void setTempEmail(String tempEmail) {
        this.tempEmail = tempEmail;
    }

    public int getNumPlayers() {
        return numPlayers;
    }
    public String deleteSelectedPlayer() {
        Player playerToRemove = null;
        for (Player player : players) {
            if (player.getName().equals(tempName)) {
                playerToRemove = player;
                break;
            }
        }

        if (playerToRemove != null) {
            players.remove(playerToRemove);
            numPlayers = players.size();
            System.out.println("Removed Player: " + playerToRemove.getName());
            return "success";  // Navigation outcome if needed
        }
        return "failure";
    }

}
