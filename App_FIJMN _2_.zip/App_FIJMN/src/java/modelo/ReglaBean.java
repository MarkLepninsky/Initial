/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import javax.inject.Named;
import javax.enterprise.context.RequestScoped;

/**
 *
 * @author nsanher1
 */
@Named(value = "reglaBean")
@RequestScoped
public class ReglaBean {

    /**
     * Creates a new instance of ReglaBean
     */
    public ReglaBean() {
    }
    
}
/*
 private String determinarResultado(String usuario, String ia) {
        if (usuario.equals(ia)) {
            return "Empate!";
        } else if ((usuario.equals("piedra") && ia.equals("tijera")) ||
                   (usuario.equals("papel") && ia.equals("piedra")) ||
                   (usuario.equals("tijera") && ia.equals("papel"))) {
            return "¡Ganaste!";
        } else {
            return "¡Perdiste!";
        }
    }*/