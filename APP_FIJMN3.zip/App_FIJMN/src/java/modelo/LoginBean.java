/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import java.util.Random;

/**
 *
 * @author nsanher1
 */
@Named(value = "loginBean")
@RequestScoped
public class LoginBean {


    private String username;
    private String password;
    
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
  

    public String login() {
        // Lógica para verificar usuario y contraseña en la base de datos
        System.out.println("Intento de login: " + username);
        return "inicio.xhtml?faces-redirect=true";
        /*if (isValidUser(username, password)) {
            return "Inicio.xhtml?faces-redirect=true"; // Redirige a Inicio.xhtml
        } else {
            // Manejo de errores: podrías mostrar un mensaje de error
            return null; // Permite que se mantenga en la misma página
        }*/
    }

    private boolean isValidUser(String username, String password) {
        // Implementa la lógica de validación aquí (ej. consulta a la base de datos)
        return "admin".equals(username) && "password".equals(password); // Ejemplo simple
    }

}
