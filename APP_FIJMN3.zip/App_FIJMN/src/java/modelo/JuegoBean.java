package modelo;

import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import java.util.Random;

@Named(value = "juegoBean")
@RequestScoped
public class JuegoBean {

    private String jugadaUsuario;
    private String jugadaIA;
    private String resultado;
    

    public String getJugadaUsuario() {
        return jugadaUsuario;
    }

    public String getJugadaIA() {
        return jugadaIA;
    }

    public String getResultado() {
        return resultado;
    }

    public void jugar(String jugada) {
        System.out.println("Jugada del usuario: " + jugada);
        this.jugadaUsuario = jugada;
        this.jugadaIA = generarJugadaIA();
        this.resultado = determinarResultado(jugada, jugadaIA);
        System.out.println("Jugada IA: " + jugadaIA);
        System.out.println("Resultado: " + resultado);
    }

    private String generarJugadaIA() {
        String[] opciones = {"piedra", "papel", "tijera"};
        int index = new Random().nextInt(opciones.length);
        return opciones[index];
    }

    private String determinarResultado(String usuario, String ia) {
        if (usuario.equals(ia)) {
            return "Empate!";
        } else if ((usuario.equals("piedra") && ia.equals("tijera")) ||
                   (usuario.equals("papel") && ia.equals("piedra")) ||
                   (usuario.equals("tijera") && ia.equals("papel"))) {
            return "¡Ganaste!";
        } else {
            return "¡Perdiste!";
        }
    }


}

